import subprocess
import sys
import requests


def get_installed_version(package_name="ddgs"):
    try:
        import importlib.metadata as im
        return im.version(package_name)
    except Exception:
        return None


def get_latest_version(package_name="ddgs"):
    try:
        resp = requests.get(
            f"https://pypi.org/pypi/{package_name}/json", timeout=5
        )
        if resp.status_code == 200:
            return resp.json()["info"]["version"]
    except Exception:
        return None
    return None


def needs_update(installed, latest):
    if not installed or not latest:
        return False
    try:
        from packaging.version import parse
        return parse(installed) < parse(latest)
    except Exception:
        return installed != latest


def update_package(package_name="ddgs"):
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-U", package_name],
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode == 0, result.stdout + result.stderr
    except subprocess.TimeoutExpired:
        return False, "Update timed out after 60 seconds."
    except Exception as e:
        return False, str(e)


def check_and_update(package_name="ddgs"):
    installed = get_installed_version(package_name)
    latest = get_latest_version(package_name)

    if installed is None:
        return {"status": "unknown", "installed": None, "latest": latest,
                "detail": "Cannot determine installed version"}
    if latest is None:
        return {"status": "unknown", "installed": installed, "latest": None,
                "detail": "Cannot reach PyPI"}

    if needs_update(installed, latest):
        success, log = update_package(package_name)
        new_installed = get_installed_version(package_name)
        return {
            "status": "updated" if success else "update_failed",
            "installed": installed,
            "latest": latest,
            "now": new_installed,
            "detail": log[:300] if log else "",
        }

    return {"status": "current", "installed": installed, "latest": latest,
            "now": installed, "detail": ""}
