To use this you need either of the following apps installed or api keys:
1.ollama
2.llmstudio

where to get ai models locally or cloud wise(locally means on your system):

1.ollama.com(both locally and cloud)
2.huggingface.co(both locally and cloud)
3.openrouter.ai(api keys)
4.openai.com(api keys)
5.claude.ai(api keys)
6.deepseek.com(api keys)
7.anywhere else you find 

1st note:api keys basically means using a key to run a model cloud wise(cloud meaning on a server or remotely)


important notes about the AI:
1.it remembers only a limited amount of tasks as excessive task remembering confuses the ai model in tasks and instruction following due to context length
2.it is not perfect and should not be used a system repair tool, it can make mistakes sometimes, its recommended you run large parameter
models such as qwen3-coder:480b<----b is the parameters(ai model brain size)
3.to use large models if you cannot run them locally on your system then you have to get large cloud models(models that run on a 
specific server or remotely)
4. an example of a large cloud model is qwen3-coder:480b