import json
import os
import time

_last_update_check = 0.0
_config = None


def _load_config():
    global _config
    if _config is not None:
        return _config

    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
    defaults = {"auto_update": True, "auto_update_interval_hours": 24}
    try:
        with open(path, "r") as f:
            _config = {**defaults, **json.load(f)}
        return _config
    except Exception:
        _config = dict(defaults)
        return _config


def _should_check_update():
    global _last_update_check
    config = _load_config()
    interval = config.get("auto_update_interval_hours", 24) * 3600
    return time.time() - _last_update_check > interval


def web_search(query, max_results=3, retries=1):
    config = _load_config()

    if config.get("auto_update", True) and _should_check_update():
        global _last_update_check
        _last_update_check = time.time()
        try:
            from .update_manager import check_and_update
            result = check_and_update("ddgs")
            if result["status"] == "updated":
                print(f"[Updater] ddgs updated: {result['installed']} -> {result['latest']}")
            elif result["status"] == "update_failed":
                print(f"[Updater] Update failed: {result['detail'][:100]}")
        except Exception as e:
            print(f"[Updater] Check skipped: {e}")

    from .search import web_search as _search
    return _search(query, max_results, retries)


def check_internet():
    from .search import check_internet as _check
    return _check()
