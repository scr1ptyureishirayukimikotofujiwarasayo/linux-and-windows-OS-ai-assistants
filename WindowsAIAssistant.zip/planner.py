import json
import os
import time
from datetime import datetime

PLAN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".active_plan.json")


class TaskPlanner:
    def __init__(self):
        self.goal = ""
        self.steps = []
        self.current = -1
        self.created_at = ""
        self._loaded = False

    def _ensure_loaded(self):
        if not self._loaded:
            self._load()

    def _load(self):
        self._loaded = True
        if os.path.exists(PLAN_FILE):
            try:
                with open(PLAN_FILE) as f:
                    data = json.load(f)
                self.goal = data.get("goal", "")
                self.steps = data.get("steps", [])
                self.current = data.get("current", -1)
                self.created_at = data.get("created_at", "")
            except Exception:
                pass

    def _save(self):
        with open(PLAN_FILE, "w") as f:
            json.dump({
                "goal": self.goal,
                "steps": self.steps,
                "current": self.current,
                "created_at": self.created_at or datetime.now().isoformat(),
            }, f, indent=2)

    def create_plan(self, goal, step_descriptions):
        self._load()
        self.goal = goal
        self.steps = []
        for i, desc in enumerate(step_descriptions):
            self.steps.append({
                "id": i + 1,
                "description": desc.strip(),
                "status": "pending",
                "result": "",
                "started_at": None,
                "completed_at": None,
            })
        self.current = -1
        self.created_at = datetime.now().isoformat()
        self._save()
        return self.steps

    def start_step(self, step_id):
        self._ensure_loaded()
        for s in self.steps:
            if s["id"] == step_id and s["status"] == "pending":
                s["status"] = "running"
                s["started_at"] = datetime.now().isoformat()
                self.current = step_id
                self._save()
                return True
        return False

    def complete_step(self, step_id, result=""):
        self._ensure_loaded()
        for s in self.steps:
            if s["id"] == step_id and s["status"] == "running":
                s["status"] = "done"
                s["result"] = result[:500]
                s["completed_at"] = datetime.now().isoformat()
                self._save()
                return True
        return False

    def fail_step(self, step_id, error=""):
        self._ensure_loaded()
        for s in self.steps:
            if s["id"] == step_id and s["status"] == "running":
                s["status"] = "failed"
                s["result"] = f"[FAILED] {error[:500]}"
                s["completed_at"] = datetime.now().isoformat()
                self._save()
                return True
        return False

    def next_pending(self):
        self._ensure_loaded()
        for s in self.steps:
            if s["status"] == "pending":
                return s
        return None

    def status(self):
        self._ensure_loaded()
        total = len(self.steps)
        done = sum(1 for s in self.steps if s["status"] == "done")
        failed = sum(1 for s in self.steps if s["status"] == "failed")
        running = sum(1 for s in self.steps if s["status"] == "running")
        lines = [
            f"Goal: {self.goal}",
            f"Progress: {done}/{total} complete, {failed} failed, {running} in progress",
        ]
        for s in self.steps:
            icon = {"pending": "○", "running": "●", "done": "✓", "failed": "✗"}.get(s["status"], "○")
            lines.append(f"  {icon} Step {s['id']}: {s['description']} [{s['status']}]")
        return "\n".join(lines)

    def summary(self):
        self._ensure_loaded()
        return json.dumps({
            "goal": self.goal,
            "steps": self.steps,
            "current": self.current,
        }, indent=2)

    def clear(self):
        self.goal = ""
        self.steps = []
        self.current = -1
        self.created_at = ""
        if os.path.exists(PLAN_FILE):
            os.remove(PLAN_FILE)
        return "Plan cleared."

    def list_steps(self):
        self._ensure_loaded()
        if not self.steps:
            return "No active plan."
        return "\n".join(
            f"  {i+1}. [{s['status']}] {s['description']}"
            for i, s in enumerate(self.steps)
        )


planner = TaskPlanner()
