import requests


def generate_response(messages, config):
    provider = config["provider_type"]
    model = config["model"]
    temperature = config.get("temperature", 0.3)

    if provider == "ollama":
        url = "http://localhost:11434/api/chat"
        payload = {"model": model, "messages": messages, "stream": False, "options": {"temperature": temperature}}
        try:
            resp = requests.post(url, json=payload, timeout=60)
            if resp.status_code == 200:
                return resp.json()["message"]["content"]
            else:
                return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"

    elif provider == "lmstudio":
        url = f"{config['base_url']}/v1/chat/completions"
        headers = {"Content-Type": "application/json"}
        payload = {"model": model, "messages": messages, "stream": False, "temperature": temperature}
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
            if resp.status_code == 200:
                return resp.json()["choices"][0]["message"]["content"]
            else:
                return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"

    elif provider == "api":
        url = f"{config['base_url']}/v1/chat/completions"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {config['api_key']}"
        }
        payload = {"model": model, "messages": messages, "stream": False, "temperature": temperature}
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=60)
            if resp.status_code == 200:
                return resp.json()["choices"][0]["message"]["content"]
            else:
                return f"Error: {resp.text}"
        except Exception as e:
            return f"Error: {e}"
    else:
        return "Unknown provider"
